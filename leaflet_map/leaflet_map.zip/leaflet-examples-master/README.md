# leaflet-examples
Simple starter examples for leaflet map projects.

## Examples
* A html template with separate CSS and Javascript files: [index.html](https://lapizistik.github.io/leaflet-examples/)
* A self contained one-file starter: [one-file.html](https://lapizistik.github.io/leaflet-examples/one-file.html)
